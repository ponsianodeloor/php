<?php
 define('DB_HOST', 'localhost');
 define('DB_NOMBRE', 'db_mvc');
 define('DB_USUARIO', 'root');
 define('DB_PASS', '');

 define('RUTA_APP', dirname(dirname(__FILE__)));
 //ruta url Ejemplo http://localhost/dropbox/php/mvc/
 define('RUTA_URL', 'http://localhost/dropbox/php/mvc');
 define('NOMBRE_SITIO', 'MVC');
?>
