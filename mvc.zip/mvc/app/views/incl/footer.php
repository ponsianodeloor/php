<script type="text/javascript" src="<?php echo RUTA_URL; ?>/js/main.js"></script>
 </body>
</html>
