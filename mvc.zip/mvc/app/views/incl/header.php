<!DOCTYPE html>
<html lang="es" dir="ltr">
 <head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device=width, initial-scale=1.0">
  <meta http-equiv="X-UA-COMPATIBLE" content="id=edge">
  <link rel="stylesheet" type="text/css" href="<?php echo RUTA_URL; ?>/css/estilos.css">
  <title><?php echo NOMBRE_SITIO; ?></title>
 </head>
 <body>
