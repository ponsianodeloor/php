<?php
 echo "<h1>Carga prueba vista articulo</h1>";
?>
