document.write(5 + 6);
