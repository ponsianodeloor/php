<?php
 //Cargamos el iniciador.php de la carpeta app
 require_once '../app/iniciador.php';


 $objIniciar = new Core;
?>
