<div class="full-box login-container cover">
 <form action="home.html" method="" autocomplete="off" class="logInForm">
  <p class="text-center text-muted"><i class="zmdi zmdi-account-circle zmdi-hc-5x"></i></p>
  <p class="text-center text-muted text-uppercase">Inicia sesión con tu cuenta</p>
  <div class="form-group label-floating">
    <label class="control-label" for="UserName">Usuario</label>
    <input class="form-control" id="UserName" type="text">
    <p class="help-block">Escribe tú nombre de usuario</p>
  </div>
  <div class="form-group label-floating">
    <label class="control-label" for="UserPass">Contraseña</label>
    <input class="form-control" id="UserPass" type="text">
    <p class="help-block">Escribe tú contraseña</p>
  </div>
  <div class="form-group text-center">
   <input type="submit" value="Iniciar sesión" class="btn btn-info" style="color: #FFF;">
  </div>
 </form>
</div>
