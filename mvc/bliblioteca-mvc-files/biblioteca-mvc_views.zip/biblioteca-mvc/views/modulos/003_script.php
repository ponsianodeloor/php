<script src="<?php echo RUTA_URL; ?>views/js/jquery-3.1.1.min.js"></script>
<script src="<?php echo RUTA_URL; ?>views/js/sweetalert2.min.js"></script>
<script src="<?php echo RUTA_URL; ?>views/js/bootstrap.min.js"></script>
<script src="<?php echo RUTA_URL; ?>views/js/material.min.js"></script>
<script src="<?php echo RUTA_URL; ?>views/js/ripples.min.js"></script>
<script src="<?php echo RUTA_URL; ?>views/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="<?php echo RUTA_URL; ?>views/js/main.js"></script>
<script>
 $.material.init();
</script>
