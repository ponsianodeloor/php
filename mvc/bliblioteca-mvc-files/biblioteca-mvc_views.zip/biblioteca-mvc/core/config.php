<?php
 define('RUTA_URL', 'http://localhost/dropbox/php/mvc/biblioteca-mvc/');
 define('COMPANY', 'Biblioteca MVC');
 date_default_timezone_set('America/Guayaquil');
?>
