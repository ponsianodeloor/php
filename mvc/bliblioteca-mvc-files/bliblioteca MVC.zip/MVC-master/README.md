# CURSO PROFESIONAL DE PHP, MVC, PDO, AJAX, MySQL
Parte del código fuente del curso profesional de PHP:  https://www.youtube.com/playlist?list=PLH_tVOsiVGzlJtytLjp6h6hRpZCxl77-n
