<?php
	const SERVERURL="http://localhost/MVC/";
	const COMPANY="SISTEMA BIBLIOTECA";
	date_default_timezone_set ("America/El_Salvador");