<?php
/*
CRUD con PostgreSQL y PHP
@author parzibyte [parzibyte.me/blog]
@date 2019-06-17

================================
Este archivo simplemente cierra
las etiquetas abiertas en
encabezado.php
================================
*/
?>    

</main>
</body>
</html>